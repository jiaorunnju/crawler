#!/bin/bash
#########################################################################
# File Name: startcrawl.sh
# Author :Jiaorun
#########################################################################

if [ -e "crawl.jar" -a -e "key.txt" -a -e "crawl.conf" ];then
    java -jar crawl.jar key.txt
else
    echo "make sure you have crawl.jar or keys.txt or crawl.conf"
fi
