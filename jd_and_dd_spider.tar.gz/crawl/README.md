## attention
the database name should be PRODUCT
and there are two tables in it:

* GOODS
id char(32),des varchar(128),seller varchar(128),url varchar(128),primary key(id)

* PRICE
id char(32),des varchar(128),price double,primary key(id,date)

the database encoding and the table encoding should use UTF-8

